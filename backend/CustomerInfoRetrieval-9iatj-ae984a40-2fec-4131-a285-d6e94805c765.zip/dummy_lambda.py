import boto3
import json
import logging

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    AWS Lambda function to handle Bedrock agent requests and retrieve customer details from DynamoDB.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    # Extract required parameters from the event
    agent = event.get('agent', 'UnknownAgent')
    actionGroup = event.get('actionGroup', 'UnknownActionGroup')
    apiPath = event.get('apiPath', '/unknown')
    httpMethod = event.get('httpMethod', 'GET')
    parameters = event.get('parameters', [])
    requestBody = event.get('requestBody', {})

    # Extract CustomerID from parameters
    customer_id = None
    for param in parameters:
        if param.get('name') == 'CustomerID':
            customer_id = param.get('value')
            break

    if not customer_id:
        return {
            'response': {
                'actionGroup': actionGroup,
                'apiPath': apiPath,
                'httpMethod': httpMethod,
                'httpStatusCode': 400,
                'responseBody': {
                    "application/json": {
                        "body": json.dumps({"error": "CustomerID is required"})
                    }
                }
            },
            'messageVersion': event.get('messageVersion', '1.0')
        }

    try:
        # Query DynamoDB
        response = dynamodb.get_item(
            TableName='TelecomCustomers',
            Key={'CustomerID': {'S': customer_id}}
        )

        if 'Item' not in response:
            return {
                'response': {
                    'actionGroup': actionGroup,
                    'apiPath': apiPath,
                    'httpMethod': httpMethod,
                    'httpStatusCode': 404,
                    'responseBody': {
                        "application/json": {
                            "body": json.dumps({"error": "Customer not found"})
                        }
                    }
                },
                'messageVersion': event.get('messageVersion', '1.0')
            }

        # Convert DynamoDB response to a readable JSON format
        customer_data = {key: list(value.values())[0] for key, value in response['Item'].items()}

        # Success response
        return {
            'response': {
                'actionGroup': actionGroup,
                'apiPath': apiPath,
                'httpMethod': httpMethod,
                'httpStatusCode': 200,
                'responseBody': {
                    "application/json": {
                        "body": json.dumps(customer_data)
                    }
                }
            },
            'messageVersion': event.get('messageVersion', '1.0')
        }

    except Exception as e:
        logger.error(f"Error fetching customer details: {str(e)}")
        return {
            'response': {
                'actionGroup': actionGroup,
                'apiPath': apiPath,
                'httpMethod': httpMethod,
                'httpStatusCode': 500,
                'responseBody': {
                    "application/json": {
                        "body": json.dumps({"error": "Internal Server Error", "details": str(e)})
                    }
                }
            },
            'messageVersion': event.get('messageVersion', '1.0')
        }
